package com.br.aula2209.controllers;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.br.aula2209.entities.Pessoa;
import com.br.aula2209.services.PessoaService;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController 
@RequestMapping("/api")
public class PessoaController {

    private final PessoaService pessoaService;

    public PessoaController(PessoaService pessoaService) {
        
        this.pessoaService = pessoaService;
    }

    @GetMapping("/mostrarPessoa")
    public String mostrar() {
        
        return "GET DO MOSTRAR PESSOA";
    }


    @PostMapping("/salvarPessoa")
    public String salvar(@RequestParam String nome, @RequestParam int idade, @RequestParam String email) {
        
        Pessoa pessoa = new Pessoa();

        pessoa.setNome(nome);
        pessoa.setIdade(idade);
        pessoa.setEmail(email);

        return pessoaService.salvar(pessoa);
    }

    @DeleteMapping("/deletarPessoa/{id}")
    public String deletar(@PathVariable Integer id) {
        return pessoaService.deletar(id);
    }

    @PutMapping ("/atualizarPessoa/{id}")
    public String atualizar(@PathVariable Integer id, @RequestBody Pessoa pessoa) {
        return pessoaService.atualizar(id, pessoa);
    }
}