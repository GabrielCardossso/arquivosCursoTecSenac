package com.br.aula2209.services;
import org.springframework.stereotype.Service;

import com.br.aula2209.entities.Pessoa;
import com.br.aula2209.repositories.PessoaRepository;

@Service
public class PessoaService {
    private final PessoaRepository pessoaRepository;

    public PessoaService(PessoaRepository pessoaRepository) {
        this.pessoaRepository = pessoaRepository;
    }

    public String salvar(Pessoa pessoa) {
        
        pessoaRepository.save(pessoa);
        return "Pessoa salva com sucesso!";
    }

    public String deletar(Integer id) {
        pessoaRepository.deleteById(id);
        return "Pessoa deletada com sucesso!";
    }

    public String atualizar(Integer id, Pessoa pessoaAtualizar) {
        
        Pessoa pessoaBD = pessoaRepository.findById(id).get();
        pessoaBD.setNome(pessoaAtualizar.getNome());
        pessoaBD.setIdade(pessoaAtualizar.getIdade());
        pessoaBD.setEmail(pessoaAtualizar.getEmail());


        pessoaRepository.save(pessoaBD);
        return "Pessoa atualizada com sucesso!";
    }

}
