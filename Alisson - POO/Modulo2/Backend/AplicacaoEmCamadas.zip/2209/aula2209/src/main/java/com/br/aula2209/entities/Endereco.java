package com.br.aula2209.entities;

public class Endereco {

}
